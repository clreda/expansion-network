[Repository](https://github.com/regulomics/expansion-network)

## Test found steady states against literature ones / Compute all steady states in model

execute:

```bash
// Install the necessary packages 
bash grn_starter.sh
// Add the additional files to the original folder "expansion-network/" cloned from GitHub
bash install.sh
```

## Command examples

- Checking if stable states in the original model are preserved by the expansion procedure: in repository, go to folder **Python/**

* For the pluripotency model:

```bash
python solve.py check pluripotency model pluripotency-partial+_expanded
// <=> in folder R/: Rscript list_all_steady_states.R model_name pluripotency concrete_model_name pluripotency-partial+_expanded literature_filename literature.spec runtype checking
```

* For the Collombet model:

```bash
python solve.py check collombet model collombet-partial+_expanded
// <=> in folder R/: Rscript list_all_steady_states.R model_name collombet concrete_model_name collombet-partial+_expanded literature_filename literature.spec runtype checking
```

- Computing all stable stables (/!\ by simulation, thus might take a while!): in repository, go to folder **Python/**

* For the pluripotency model:

```bash
python solve.py enumerate pluripotency model pluripotency-partial+_expanded
// <=> in folder R/: Rscript list_all_steady_states.R model_name pluripotency concrete_model_name pluripotency-partial+_expanded runtype computing
