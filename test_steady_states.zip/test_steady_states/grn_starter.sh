#!\bin\bash

# for Debian-like distributions
# use Python 2.7+

## install Anaconda for Linux distributions
#wget https://repo.anaconda.com/archive/Anaconda2-2019.07-Linux-x86_64.sh
#bash Anaconda2-2019.07-Linux-x86_64.sh
conda create -n env_grn_inference python=2.7
conda activate env_grn_inference
apt install python-pip
python -m pip install z3-solver
#apt-get install -y libigraph0-dev
python -m pip install python-igraph
#apt install -y r-base
#apt install -y gfortran-7
# on Jessie: install R 3.5.3
# content of /etc/apt/sources.list
#... deb http://ftp.debian.org/debian/ jessie main
#... deb https://cloud.r-project.org/bin/linux/debian jessie-cran35/
#apt-get update
#apt-get install r-base r-base-dev
#R -e 'tmp <- installed.packages(); installedpkgs <- as.vector(tmp[is.na(tmp[,"Priority"]), 1]); remove.packages(installedpkgs)'
R -e 'install.packages("QCA", repos="http://cran.us.r-project.org")'
R -e 'install.packages("XML", repos="http://cran.us.r-project.org")'
R -e 'install.packages("igraph", repos="http://cran.us.r-project.org")'
