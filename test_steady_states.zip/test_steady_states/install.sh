#!/bin/bash

cp list_all_steady_states.R ../expansion-network/R/
cp grn_starter.sh ../expansion-network/
cp solve.py ../expansion-network/Python/solve.py
cp -R models/ ../expansion-network/examples/
exit
