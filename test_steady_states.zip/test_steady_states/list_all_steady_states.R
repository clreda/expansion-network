## To put in root folder of "expansion-network" project
source("boolean_reducer.R")

pst <- function(x, sep='') paste0(x, collapse=sep)

get_steady_states <- function(args, path, print_st=F, tested_states=NULL) {
	n=read.table(paste0(path, args$concrete_model_name, ".net"), sep="\n")
	## n is the number of nodes in the model
	nodes=strsplit(as.character(n[6,1]), ";")[[1]]
	nodes=nodes[1:(length(nodes)-1)]
	nodes=as.vector(sapply(sapply(nodes, function(x) strsplit(x, "[[]")[[1]][1]), function(x) gsub(" ", "", x)))
	n=length(nodes)
	if (is.null(tested_states)) {
		## state = vector in {0,1}^n where n is the number of nodes
		print("MSG: Generate steady states")
		possible_states <- apply(enumerateGrayCode(n), 1, pst)
	} else {
		## state = name of state in literature state file
		print("MSG: Use literature states")
		possible_states <- tested_states
	}
	## solmax=0 should look for all solutions
	## steadyStates=1 enforces the condition of ending on a steady state
	## nstep=0 tests if the initial state is a steady state
	is_steady_cmd <- function(state) {
		cmd <- "cd ../Python/ ; "
		cmd <- c(cmd, paste0("python solve.py launch ", args$model_name, " --model ", args$concrete_model_name))
		cmd <- c(cmd, " --experiments observations_state")
		cmd <- c(cmd, paste0(" --q0 ", state, " --nstep 0 --solmax 0 --steadyStates 1"))
		pst(cmd)
	}
	steady_states <- NULL
	print(paste("MODEL", args$model_name, "ID", args$concrete_model_name))
	for (state in possible_states) {
		print(is_steady_cmd(state))
		trajectories <- system(is_steady_cmd(state), intern=T)
		if (print_st) cat(pst(trajectories, "\n"), "\n")
		trajectories <- pst(trajectories, " ")
		is_steady <- !grep("#trajectories = 0", trajectories)
		print(paste0("Tested state is: ", state, " is steady? ", ifelse(length(is_steady) > 0, "yes", "no")))
		if (is.null(tested_states)) {
			state = strsplit(state, "")[[1]]
			if (length(is_steady) > 0) steady_states <- c(steady_states, pst(sapply(1:n, function(i) paste0(nodes[i], "=", state[i])), " and# "))
		} else steady_states <- c(steady_states, if (length(is_steady) > 0) state else NULL)
		system("cd ../R/")
	}
	steady_states
}

convert_state_to_str <- function(states) {
	i <- 1
	str <- NULL
	for (state in states) {
		title=paste0("$Steady", i, ":=")
		start="{"
		stt=strsplit(paste0(" ", state), "#")[[1]]
		end="};\n"
		str <- c(str, title, start, stt, end)
		i <- i+1
	}
	pst(str, "\n")
}

convert_str_to_state <- function(filename) {
	file=gsub("\n", "", pst(as.character(read.table(filename, sep="\n")[,1])))
	phenotypes <- strsplit(file, "[{]")[[1]]
	phenotypes <- phenotypes[2:length(phenotypes)]
	phenotypes <- sapply(phenotypes, function(x) strsplit(x, "[}]")[[1]][1])
	phenotypes <- sapply(phenotypes, function(x) gsub(" and ", " and# ", x))
	phenotypes <- as.vector(sapply(phenotypes, function(x) gsub("^ ", "", gsub(" = ", "=", x))))
	phenotypes
}

convert_str_to_state_name <- function(filename) {
	lst <- as.character(read.table(filename, sep="\n")[,1])
	lst <- names(unlist(sapply(lst, function(x) grep(":=", x))))
	lst <- sapply(lst, function(x) gsub(":=", "", x))
	lst <- sapply(lst, function(x) {
		chr <- strsplit(x, "")[[1]]
		pst(chr[2:length(chr)])
	})
	lst
}

convert_state_to_binary_vector <- function(states, args, path) {
	n=read.table(paste0(path, args$concrete_model_name, ".net"), sep="\n")
	## n is the number of nodes in the model
	nodes=strsplit(as.character(n[6,1]), ";")[[1]]
	nodes=nodes[1:(length(nodes)-1)]
	nodes=as.vector(sapply(sapply(nodes, function(x) strsplit(x, "[[]")[[1]][1]), function(x) gsub(" ", "", x)))
	to_binary_vector <- function(state) {
		ls <- strsplit(state, " and# ")[[1]]
		ls <- lapply(ls, function(x) strsplit(x, "=")[[1]])
		nodes_ <- sapply(ls, function(x) x[1])
		ids <- unlist(sapply(nodes, function(n) which(nodes_ == n)))
		ls <- ls[ids]
		paste0(as.vector(sapply(ls, function(x) x[2])), collapse="")
	}
	as.vector(sapply(states, to_binary_vector))
}

steady_states_retrieval <- function(states, literature_states) {
	confusion <- matrix(0, nrow=2, ncol=2)
	if (length(states) == 0) TP <- 0
	else TP <- sum(sapply(states, function(x) x %in% literature_states))
	if (length(states) == 0) n <- 0
	else n <- length(strsplit(states[1], "=")[[1]])
	TN <- 2**n - TP
	FP <- length(states)-TP
	if (length(states) == 0) FN <- length(literature_states) 
	else FN <- sum(sapply(literature_states, function(x) !(x %in% states)))
	colnames(confusion) <- c("True Steady States", "False Steady States")
	rownames(confusion) <- c("Found Steady States", "Not Found Steady States")
	confusion[1, ] <- c(TP, FP)
	confusion[2, ] <- c(FN, TN)
	confusion
}

#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>#
#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>#

## ARGUMENTS
# --- MANDATORY ARGUMENTS
# model_name
# concrete_model_name stored in examples/models/model_name/concrete_model.net MUST BE A CONCRETE MODEL (i.e. no optional interactions nor GRFs)
# --- OPTIONAL ARGUMENTS
# literature_filename filename storing the steady states extracted from the literature in a similar fashion as in observations.spec files (stored in examples/models/model_name folder)
#                     that is, for each state:
#		      "
#                     $name_state:=
#			{
#			 gene_1 = 1 and
#			 gene_2 = 0 and
#			 ...
#			 gene_n = 1 and
#			 gene_n+1 = 1
#			};
#		      "
# runtype: either "computing" which gives all stable states by simulation, either "checking" which checks if all stable states in literature 
# are indeed stable in this framework
if (sys.nframe() == 0) {
	## Even arguments are argument names
	## Odd arguments are argument values
	args = commandArgs(trailingOnly=T)
	stopifnot(length(args) %% 2 == 0)
	## default test
	if (length(args) == 0) {
		args = c("model_name", "dummy", "concrete_model_name", "model", "literature_filename", "literature.spec", "runtype", "checking")
	}
	names_ids = which(sapply(1:length(args), function(x) x%%2==1))
	argnames = c("model_name", "concrete_model_name", "literature_filename", "runtype")
	stopifnot(all(sapply(args[names_ids], function(x) x %in% argnames)))
	stopifnot(all(sapply(argnames, function(x) x %in% args[names_ids])))
	path=paste0("../examples/models/", args[2], "/")
	args_ <- sapply(args[-names_ids], list)
	names(args_) <- args[names_ids]
	args <- args_
	file_folder <- "../examples/models/"
	model_path <- paste0(file_folder, args$model_name, "/")
	if (args[argnames[length(argnames)]] == "computing") {
		system(paste0("cp ",model_path, "observations.spec ",model_path, "observations_state.spec"))
		states <- get_steady_states(args, path, print_st=F)
		str_states <- convert_state_to_str(states)
		filename <- paste0(path, args$concrete_model_name, "-steady_states.spec")
		write(str_states, file=filename)
		if ("literature_filename" %in% names(args) && length(states) > 0) {
			literature_states <- convert_str_to_state(paste0(path, args$literature_filename))
			confusion_matrix <- steady_states_retrieval(states, literature_states)
			filename <- paste0(path, args$concrete_model_name, "-confusion-computing.csv")
			print(confusion_matrix)
			write.csv(confusion_matrix, file=filename)
		}
	}
	if (args[argnames[length(argnames)]] == "checking") {
		if ("literature_filename" %in% names(args)) {
			system(paste0("cat ",model_path, "observations.spec ",model_path, args$literature_filename, " > ",model_path, "observations_state.spec"))
			literature_states <- convert_str_to_state_name(paste0(path, args$literature_filename))
			states <- get_steady_states(args, path, print_st=F, tested_states=literature_states)
			confusion_matrix <- steady_states_retrieval(states, literature_states)
			filename <- paste0(path, args$concrete_model_name, "-confusion-checking.csv")
			print(confusion_matrix)
			write.csv(confusion_matrix, file=filename)
		}
	}
}
